// Stores available languages as enums.

const Language = Object.freeze({
  English: "english",
  Russian: "russian"
});

export { Language };